﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Console;

namespace PlantGameVerXAML
{
    public partial class Naming : Page
    {
        public Player MyPlayer = new Player();
        public Plant MyPlant = new Plant();
        public Naming()
        {
            InitializeComponent();
        }

        public void Continue_Click(object sender, RoutedEventArgs e)
        {
            if (PlayerName.Text == "" || PlantName.Text == "")
            {
                //nothin happens
                WriteLine("Write your name and your plant's name!");
            }
            else
            {
                NavigationService.Navigate(new MainGame(MyPlayer, MyPlant));
            }
        }

        public void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            //GetPlayerName();
            MyPlayer.PlayerName = PlayerName.Text;
            Console.WriteLine($"{MyPlayer.PlayerName}");
        }

        public void PlantName_TextChanged(object sender, TextChangedEventArgs e)
        {
            //plant name changed
            MyPlant.PlantName = PlantName.Text;
            Console.WriteLine($"{MyPlant.PlantName}");
        }   
    }
}
