﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;
using System.Windows;
using static System.Console;

namespace PlantGameVerXAML
{
    internal class Game
    {
        
        //public Store MyStore = new Store();
        //public Inventory MyStorage = new Inventory();

        public Game()
        {
            //Start();
        }

        public void Start(Plant MyPlant)
        {
                do
                {
                    if (MyPlant.Happiness <= 3)
                    {

                    }
                    else if (MyPlant.Happiness == 4 || MyPlant.Happiness == 5 || MyPlant.Happiness == 6)
                    {
                        //sprout picture
                        //MyPlant.UpdateStatus((BitmapImage)(PlantDisplay.Source = new BitmapImage(new Uri("images/sprout.jpg", UriKind.Absolute))));
                    }

                    else if (MyPlant.Happiness == 7 || MyPlant.Happiness == 8 || MyPlant.Happiness == 9)
                    {
                        //almost picture PlantDisplay
                        //MyPlant.UpdateStatus((BitmapImage)(PlantDisplay.Source = new BitmapImage(new Uri("images/almost.jpg", UriKind.Absolute))));
                    }
                }

                while (MyPlant.Happiness < 10);

                if (MyPlant.Happiness == 10)
                {
                    //MyPlant.UpdateStatus((BitmapImage)(PlantDisplay.Source = new BitmapImage(new Uri("images/blooming.jpg", UriKind.Absolute))));
                }
        }


           
    }
}
