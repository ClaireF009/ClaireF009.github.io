﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;
using System.Windows;
using static System.Console;
using System.Windows.Controls;

namespace PlantGameVerXAML
{
    public class Player
    {

        public string PlayerName;
        public Inventory MyStorage = new Inventory();


        public Player()
        {
        //constructor
        }

        public void GetPlayerName()
        {
            WriteLine("What is your name?");
            PlayerName = ReadLine();
            WriteLine($"Great! Your name is {PlayerName}.");
        }

        public void NamePlant(Plant MyPlant)
        {
        WriteLine("What do you want your plant's name to be?");
        MyPlant.PlantName = ReadLine();
        WriteLine($"{MyPlant.PlantName} is a great name!");
        }
        public int WaterPlant(Plant MyPlant)
        {
        //decreases the plant's thirst and increases happiness

        if (MyPlant.PlantThirst >= 0)
            {
            MyPlant.Happiness++;

            MyPlant.PlantThirst -= 2;

            WriteLine("You have watered your plant!");

            return MyPlant.PlantThirst;
            }
        else if (MyPlant.PlantThirst <= 0)
            {
            WriteLine("Your plant is no longer thirsty!");
            WriteLine($"Try coming back later to water {MyPlant.PlantName}.");

            return MyPlant.PlantThirst;
            }
        else
            {
            return MyPlant.PlantThirst;
            }
        }

    public void TurnPlant(Plant MyPlant)
    {
        //allows the player to turn plant, increases happiness and thirst

        if (MyPlant.Direction == true)
        {
            MyPlant.Direction = false;
            WriteLine("Your plant is now facing the door!");
            MyPlant.Happiness++;
            MyPlant.PlantThirst++;
        }
        else if (MyPlant.Direction == false)
        {
            MyPlant.Direction = true;
            WriteLine("Your plant is now facing the window!");
            MyPlant.Happiness++;
            MyPlant.PlantThirst++;
        }
    }


        public int FertilizePlant(Plant MyPlant)
    //increases plant happiness and thirst
    {
        if (Convert.ToInt32(MyStorage.fertlist.Count) == 0)
        {
            WriteLine($"You have {MyStorage.fertlist.Count} bags of fertilizer!");
            WriteLine("Come back after buying some fertilizer from the store!");
            WriteLine("Enter an action.");

            return MyStorage.fertlist.Count;
        }
        else
        {
            WriteLine($"You currently have {MyStorage.fertlist[0]} bag(s) of fertilizer.");
            WriteLine("Would you like to fertilize your plant?");
            WriteLine("Type 'yes' or 'no.'");
            string FertAmt = ReadLine();

            if (FertAmt == "no")
            {
                WriteLine("Come back later!");
                WriteLine("Enter an action.");

                return MyStorage.fertlist.Count;
            }
            else if (FertAmt == "yes")
            {

                //Convert.ToInt32(MyStorage.fertlist.Count);
                MyPlant.Happiness = MyPlant.Happiness + MyStorage.fertlist[0];
                MyStorage.fertlist.Clear();
                MyPlant.PlantThirst++;
                WriteLine("You used up all your fertilizer!");
                WriteLine("You have fertilized your plant!");
                WriteLine("Enter an action.");

                return MyPlant.Happiness;

            }

        }
        return MyStorage.fertlist.Count;
    }


    //public void ViewInventory()
    //{
    //    MyStorage.Print();
    //    WriteLine("Enter an action.");
    //}

 
    }  
}
