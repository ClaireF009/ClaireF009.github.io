﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Media.Imaging;

namespace PlantGameVerXAML
{

    public class Plant
    {
        public int PlantThirst = 10;
        public int Happiness = 0;
        public bool Direction = true;
        public string PlantName { get; set; }
        //public string[] cnames = { "Dahlia", "Sunflower", "Tulip", "Daffodil" };

        public Plant()
        {

        }

    }
}


