﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Shapes;
using static System.Console;

namespace PlantGameVerXAML
{
    public class Compliment
    {
        public List<string> compliments = new List<string>();
        public string Text { get; set; }
        public Compliment() { }

        public void ParseCompliments()
            //taken from Chat GPT
        {
            string[] myArray = File.ReadAllLines("compliments.txt");
            foreach (string line in myArray)
            {
                
                string[] parts = line.Split(',');
                
                compliments.Add(line);
            }
        }

        public void RandomCompliment()
        {
            Random random = new Random();

            int index = random.Next(compliments.Count);

            string randomComp = compliments[index];

            WriteLine(randomComp);
        }


        
    }
}
