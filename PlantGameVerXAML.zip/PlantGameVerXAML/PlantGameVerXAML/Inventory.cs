﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace PlantGameVerXAML
{
    public class Inventory
    {

        //public string[] cnames = { "Dahlia", "Sunflowers", "Tulips", "Daffodils" };
        //public List<string> clippings = new List<string>();

        //the extra list and array were part of a plan to randomize plant names, but I couldn't get it to work in time

        public List<int> fertlist = new List<int>();
        public List<string> compliments = new List<string>();

        public Inventory()
        {
            //constructor
        }

        public void StoreFert(Item Fertilizer)
        {
            fertlist.Add(Fertilizer.Quantity);
        }

        public void Print()
        {
            if (fertlist.Count == 0)
            {
                WriteLine("You have no items in your inventory!");
                ReadKey();
                Clear();
            }
            else
            {

                WriteLine("Here is what is currently in your inventory:");
                WriteLine($"You have {fertlist[0]} bag(s) of fertilizer.");

                WriteLine("Please press any key to continue.");
                ReadKey();
                Clear();
            }

        }

        //These are extra methods I wanted to add to the game, but ran out of time to implement them

        //method for taking fertilizer out of the player's inventory
        //public void DecreaseFert()
        //{
        //    //fertlist.Add(fertlist - a);
        //    fertlist[0] = fertlist.Count - a;
        //    WriteLine($"{fertlist.Count}");
        //    ReadKey();
        //    //Convert.ToInt32(fertlist.Count) -= a;
        //    //int v = fertlist.Count;

        //    //v -= Convert.ToInt32(FertAmt);
        //}

        //method for adding a plant clipping to the player inventory
        //public void StoreClip(Plant Clipping)
        //{
        //    clippings.Add(Clipping.PlantName);

        //    WriteLine(clippings.Count);
        //}

    }
}
