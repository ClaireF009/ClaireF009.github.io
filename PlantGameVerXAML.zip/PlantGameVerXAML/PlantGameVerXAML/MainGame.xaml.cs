﻿using PlantGameVerXAML;
using PlantGameVerXAML.Properties;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Console;

namespace PlantGameVerXAML
{
    public partial class MainGame : Page
    {
        Plant MyPlant;
        Player MyPlayer;
        Compliment randcomp = new Compliment();
        TextBlock compBox = new TextBlock();
        bool isConditionTrue = false;

        public MainGame(Player p , Plant s)
        {
            InitializeComponent();
            //p and s variables added by Mr. McDonald during class
            MyPlayer = p;
            MyPlant = s;
        }

        public void Rotate_Click(object sender, RoutedEventArgs e)
        {

            if (MyPlant.Direction == true)
            {
                MyPlant.Direction = false;

                //turning code taken from stackoverflow user luvieere
                //https://stackoverflow.com/questions/3005219/how-to-flip-image-in-wpf

                PlantDisplay.RenderTransformOrigin = new Point(0.5, 0.5);
                ScaleTransform flipTrans = new ScaleTransform();
                flipTrans.ScaleX = -1;
                PlantDisplay.RenderTransform = flipTrans;

                MyPlant.Happiness++;
                MyPlant.PlantThirst++;
            }
            else if (MyPlant.Direction == false)
            {
                MyPlant.Direction = true;

                PlantDisplay.RenderTransformOrigin = new Point(0.5, 0.5);
                ScaleTransform flipTrans = new ScaleTransform();
                flipTrans.ScaleX = 1;
                PlantDisplay.RenderTransform = flipTrans;

                MyPlant.Happiness++;
                MyPlant.PlantThirst++;
            }
                Check();
        }

        private void Water_Click(object sender, RoutedEventArgs e)
        {
            MyPlayer.WaterPlant(MyPlant);
            Check();
        }

        public void Spawn()
        {
            compBox.Visibility = Visibility.Visible;
            compBox.FontSize = 20;
            compBox.Height = 70;
            compBox.Width = 500;
        }
        public void Compliment_Click(object sender, RoutedEventArgs e)
        {
            Spawn();
            randcomp.ParseCompliments();

            WriteLine($"{randcomp.compliments}");

            randcomp.RandomCompliment();

            WriteLine($"{randcomp.compliments.Count}");

            
            compBox.Text = Convert.ToString(randcomp);
            //CompBox.Text = randcomp.compliments.Count;

            //randcomp.compliments.Clear();
            
        }

        public void UpdateTextBox()
        {
            
        }
        //private void UpdateTextBox()
        //{
        //    // Generate the random text and update the text box
            
        //    CompBox.Text = randcomp.compliments.Count;
        //}
        public void Check()
        {
           
                if (MyPlant.Happiness <= 5)
                {
                   

                }
                else if (MyPlant.Happiness == 6 || MyPlant.Happiness == 7 || MyPlant.Happiness == 8|| MyPlant.Happiness == 9|| MyPlant.Happiness == 10|| MyPlant.Happiness == 11|| MyPlant.Happiness == 12)
                {
                    //sprout picture
                    //MyPlant.UpdateStatus((BitmapImage)(PlantDisplay.Source = new BitmapImage(new Uri("images/sprout.jpg", UriKind.Absolute))));
                    PlantDisplay.Source = new BitmapImage(new Uri("images/sprout.jpg", UriKind.Relative));
                }

                else if (MyPlant.Happiness == 13 || MyPlant.Happiness == 14 || MyPlant.Happiness == 15|| MyPlant.Happiness == 16|| MyPlant.Happiness == 17|| MyPlant.Happiness == 18|| MyPlant.Happiness == 19)
                {
                    //almost picture PlantDisplay
                    //MyPlant.UpdateStatus((BitmapImage)(PlantDisplay.Source = new BitmapImage(new Uri("images/almost.jpg", UriKind.Absolute))));
                    PlantDisplay.Source = new BitmapImage(new Uri("images/almost.jpg", UriKind.Relative));
                }
           
            else if (MyPlant.Happiness == 20)
            {
                //MyPlant.UpdateStatus((BitmapImage)(PlantDisplay.Source = new BitmapImage(new Uri("images/blooming.jpg", UriKind.Absolute))));
                PlantDisplay.Source = new BitmapImage(new Uri("images/blooming.jpg", UriKind.Relative));
                bool isConditionTrue = true;
                WinCondition();
            }

            else
            {

            }
        }
        public void WinCondition()
        {
           if (isConditionTrue == false)
                {
                    myTextBlock.Visibility = Visibility.Collapsed;
                }
           else
                {
                    myTextBlock.Visibility = Visibility.Visible;
                }
        }

        
    }
}



//do
//{
//    if (MyPlant.Happiness <= 3)
//    {


//    }
//    else if (MyPlant.Happiness == 4 || MyPlant.Happiness == 5 || MyPlant.Happiness == 6)
//    {
//        //sprout picture
//        //MyPlant.UpdateStatus((BitmapImage)(PlantDisplay.Source = new BitmapImage(new Uri("images/sprout.jpg", UriKind.Absolute))));
//        PlantDisplay.Source = new BitmapImage(new Uri("images/sprout.jpg", UriKind.Relative));
//    }

//    else if (MyPlant.Happiness == 7 || MyPlant.Happiness == 8 || MyPlant.Happiness == 9)
//    {
//        //almost picture PlantDisplay
//        //MyPlant.UpdateStatus((BitmapImage)(PlantDisplay.Source = new BitmapImage(new Uri("images/almost.jpg", UriKind.Absolute))));
//        PlantDisplay.Source = new BitmapImage(new Uri("images/almost.jpg", UriKind.Relative));
//    }
//}

//while (MyPlant.Happiness < 10);

//if (MyPlant.Happiness == 10)
//{
//    //MyPlant.UpdateStatus((BitmapImage)(PlantDisplay.Source = new BitmapImage(new Uri("images/blooming.jpg", UriKind.Absolute))));
//    PlantDisplay.Source = new BitmapImage(new Uri("images/blooming.jpg", UriKind.Relative));
//}